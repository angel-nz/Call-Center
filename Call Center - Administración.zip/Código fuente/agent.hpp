#ifndef AGENT_HPP_INCLUDED
#define AGENT_HPP_INCLUDED

#include <iostream>
#include <string>

#include "calllist.hpp"
#include "name.hpp"
#include "time.hpp"

class Agent {
    private:
        std::string ida;
        Name agent;
        std::string speciality;
        std::string extension;
        Time schedule;
        Time xhour;
        CallList callList;

    public:
        Agent();
        Agent(const Agent&);

        std::string getIda() const;
        Name getAgent() const;
        std::string getSpeciality() const;
        std::string getExtension() const;
        Time getSchedule() const;
        Time getXhour() const;
        CallList& getCallList();

        std::string toString(const bool&) const;

        void setIda(const std::string&);
        void setAgent(const Name&);
        void setSpeciality(const std::string&);
        void setExtension(const std::string&);
        void setSchedule(const Time&);
        void setXhour(const Time&);
        void setCallList(const CallList&);

        Agent& operator = (const Agent&);

        bool operator == (const Agent&) const;
        bool operator != (const Agent&) const;
        bool operator < (const Agent&) const;
        bool operator <= (const Agent&) const;
        bool operator > (const Agent&) const;
        bool operator >= (const Agent&) const;

        friend std::ostream& operator << (std::ostream&, const Agent&);
        friend std::istream& operator >> (std::istream&, Agent&);
};

#endif // AGENT_HPP_INCLUDED
