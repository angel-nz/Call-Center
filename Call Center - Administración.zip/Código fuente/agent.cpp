#include "agent.hpp"

using namespace std;

Agent::Agent(){ }

Agent::Agent(const Agent& a) : ida(a.ida), agent(a.agent), speciality(a.speciality), extension(a.extension), schedule(a.schedule), xhour(a.xhour), callList(a.callList) { }

string Agent::getIda() const{
    return ida;
}

Name Agent::getAgent() const{
    return agent;
}

string Agent::getSpeciality() const{
    return speciality;
}

string Agent::getExtension() const{
    return extension;
}

Time Agent::getSchedule() const{
    return schedule;
}

Time Agent::getXhour() const{
    return xhour;
}

CallList& Agent::getCallList(){
    return callList;
}

string Agent::toString(const bool& clList = false) const{
    setlocale(LC_CTYPE, "spanish");

    string info;

    info = "#";
    info+= ida;
    info+= " | ";
    info+= agent.toString();
    info+= " | ";
    info+= speciality;
    info+= " | ";
    info+= extension;
    info+= " | ";
    info+= schedule.toString();
    info+= " | ";
    info+= xhour.toString();

    if(clList){
        info+= "\n\n";
        info+= "Clientes:\n";
        info+= "ID-C | Nombre del Cliente | Hora | Duraci�n";
        info+= "\n";
        info+= callList.toString();
        info+= "\n";
    }

    return info;
}

void Agent::setIda(const string& i){
    ida = i;
}

void Agent::setAgent(const Name& a){
    agent = a;
}

void Agent::setSpeciality(const string& sp){
    speciality = sp;
}

void Agent::setExtension(const string& e){
    extension = e;
}

void Agent::setSchedule(const Time& sc){
    schedule = sc;
}

void Agent::setXhour(const Time& xh){
    xhour = xh;
}

void Agent::setCallList(const CallList& cl){
    callList = cl;
}

Agent& Agent::operator=(const Agent& a){
    ida = a.ida;
    agent = a.agent;
    speciality = a.speciality;
    extension = a.extension;
    schedule = a.schedule;
    xhour = a.xhour;
    callList = a.callList;

    return *this;
}

bool Agent::operator==(const Agent& a) const{
    return agent == a.agent;
}

bool Agent::operator!=(const Agent& a) const{
    return agent != a.agent;
}

bool Agent::operator<(const Agent& a) const{
    return agent < a.agent;
}

bool Agent::operator<=(const Agent& a) const{
    return agent <= a.agent;
}

bool Agent::operator>(const Agent& a) const{
    return agent > a.agent;
}

bool Agent::operator>=(const Agent& a) const{
    return agent >= a.agent;
}

ostream& operator << (ostream& os, const Agent& a){
    os << a.ida << endl;
    os << a.agent.toString() << endl;
    os << a.speciality << endl;
    os << a.extension << endl;
    os << a.schedule.toString() << endl;
    os << a.xhour.toString();

    return os;
}

istream& operator >> (istream& is, Agent& a){
    getline(is, a.ida);
    is >> a.agent;
    getline(is, a.speciality);
    getline(is, a.extension);
    is >> a.schedule;
    is >> a.xhour;

    return is;
}
