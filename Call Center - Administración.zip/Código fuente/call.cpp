#include "call.hpp"

using namespace std;

Call::Call() { }

Call::Call(const Call& c) : idc(c.idc), client(c.client), attention(c.attention), duration(c.duration) { }

string Call::getIdc() const{
    return idc;
}

Name Call::getClient() const{
    return client;
}

Time Call::getAttention() const{
    return attention;
}

Time Call::getDuration() const{
    return duration;
}

void Call::setIdc(const string& i){
    idc = i;
}

void Call::setClient(const Name& c){
    client = c;
}

void Call::setAttention(const Time& a){
    attention = a;
}

void Call::setDuration(const Time& d){
    duration = d;
}

string Call::toString() const{
    string info;

    info = "#";
    info+= idc;
    info+= " | ";
    info+= client.toString();
    info+= " | ";
    info+= attention.toString();
    info+= " | ";
    info+= duration.toString();

    return info;
}

Call& Call::operator=(const Call& c){
    idc = c.idc;
    client = c.client;
    attention = c.attention;
    duration = c.duration;

    return *this;
}

bool Call::operator==(const Call& c) const{
    return idc == c.idc;
}

bool Call::operator!=(const Call& c) const{
    return idc != c.idc;
}

bool Call::operator<(const Call& c) const{
    return idc < c.idc;
}

bool Call::operator<=(const Call& c) const{
    return idc <= c.idc;
}

bool Call::operator>(const Call& c) const{
    return idc > c.idc;
}

bool Call::operator>=(const Call& c) const{
    return idc >= c.idc;
}

ostream& operator << (ostream& os, const Call& c){
    os << c.idc << endl;
    os << c.client.toString() << endl;
    os << c.attention.toString() << endl;
    os << c.duration.toString();

    return os;
}

istream& operator >> (istream& is, Call& c){
    getline(is, c.idc);
    is >> c.client;
    is >> c.attention;
    is >> c.duration;

    return is;
}
