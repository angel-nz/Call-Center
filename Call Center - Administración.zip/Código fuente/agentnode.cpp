#include "agentnode.hpp"

AgentNode::AgentNode() : dataPtr(nullptr), prev(nullptr), next(nullptr) { }

AgentNode::AgentNode(const Agent& a) : dataPtr(new Agent(a)), prev(nullptr), next(nullptr) {
    if(dataPtr == nullptr)
        throw AgentNodeException("!!! LISTA LLENA !!!, al usar AgentNode");
}

AgentNode::~AgentNode(){
    delete dataPtr;
}

Agent* AgentNode::getDataPtr(){
    if(dataPtr == nullptr)
        throw AgentNodeException("!!! DATO INEXISTENTE !!!, al usar getDataPtr");
    return dataPtr;
}

Agent AgentNode::getData(){
    return *dataPtr;
}

AgentNode* AgentNode::getPrev(){
    return prev;
}

AgentNode* AgentNode::getNext(){
    return next;
}

void AgentNode::setDataPtr(Agent* p){
    dataPtr = p;
}

void AgentNode::setData(const Agent& a){
    delete dataPtr;

    dataPtr = new Agent(a);

    if(dataPtr == nullptr)
        throw AgentNodeException("!!! LISTA LLENA !!!, al usar setData");
}

void AgentNode::setPrev(AgentNode* p){
    prev = p;
}

void AgentNode::setNext(AgentNode* n){
    next = n;
}
