#ifndef LISTEXCEPTION_HPP_INCLUDED
#define LISTEXCEPTION_HPP_INCLUDED

#include <exception>
#include <string>

class ListException : public std::exception{
    private:
        std::string warn;

    public:
        explicit ListException(const char* warning) : warn(warning) { }

        explicit ListException(const std::string& warning) : warn(warning) { }

        virtual ~ListException() throw () { }

        virtual const char* what() const throw () {
            return warn.c_str();
        }
};

#endif // LISTEXCEPTION_HPP_INCLUDED
