#include "agentlist.hpp"

using namespace std;

AgentList::AgentList() : header(new AgentNode){
    if(header == nullptr)
        throw ListException("!!! LISTA LLENA !!!, iniciando lista");
    header -> setPrev(header);
    header -> setNext(header);
}

bool AgentList::isEmpty(){
    return header -> getNext() == header;
}

string AgentList::toString(const bool& withCallList){
    AgentNode* aux(header -> getNext());
    string info;
    while(aux != header){
        if(withCallList)
            info+= "Agente:\nID-A | Nombre del Agente | Especialidad | Extensi�n | Horario | Horas Extra\n";
        info+= aux -> getData().toString(withCallList);
        info+= "\n";

        aux = aux -> getNext();
    }
    return info;
}

bool AgentList::isValidPos(AgentNode* an){
    AgentNode* aux(header -> getNext());
    while(aux != header){
        if(an == aux)
            return true;
        aux = aux -> getNext();
    }
    return false;
}

void AgentList::insertData(AgentNode* an, const Agent& a){
    if(an != nullptr and !isValidPos(an))
        throw ListException("!!! POSICION INVALIDA !!!, al usar insertData");
    if(an == nullptr)
        an = header;
    AgentNode* aux(new AgentNode(a));
    if(aux == nullptr)
        throw ListException("!!! LISTA LLENA !!!, al usar insertData");
    aux -> setPrev(an);
    aux -> setNext(an -> getNext());
    an -> getNext() -> setPrev(aux);
    an -> setNext(aux);
}

AgentNode* AgentList::getPrevPos(AgentNode* an){
    if(an == header -> getNext() or !isValidPos(an))
        return nullptr;
    return an -> getPrev();
}

AgentNode* AgentList::getNextPos(AgentNode* an){
    if(an == header -> getPrev() or !isValidPos(an))
        return nullptr;
    return an -> getNext();
}

void AgentList::deleteData(AgentNode* an){
    if(!isValidPos(an))
        throw ListException("!!! POSICION INVALIDA !!!, al usar deleteData");

    an -> getPrev() -> setNext(an -> getNext());
    an -> getNext() -> setPrev(an -> getPrev());

    delete an;
}

AgentNode* AgentList::findData(const Agent& a){
    AgentNode* aux(header -> getNext());

    while(aux != header){
        if(aux -> getData() == a)
            return aux;
        aux = aux -> getNext();
    }
    return nullptr;
}

void AgentList::deleteAll(){
    AgentNode* aux;
    while(header -> getNext() != header){
        aux = header -> getNext();
        header -> setNext(aux -> getNext());
        delete aux;
    }
    header -> setPrev(header);
}

AgentList::~AgentList(){
    deleteAll();

    delete header;
}

void AgentList::copyAll(const AgentList& al){
    AgentNode* aux(al.header -> getNext());
    AgentNode* nNode;

    while(aux != al.header){
        nNode = new AgentNode(aux -> getData());
        if(nNode == nullptr)
            throw ListException("!!! LISTA LLENA !!!, al usar copyAll");
        nNode -> setPrev(header -> getPrev());
        nNode -> setNext(header);
        aux = aux -> getNext();
    }
}

AgentList::AgentList(const AgentList& al) : AgentList(){
    copyAll(al);
}

AgentNode* AgentList::getFirstPos(){
    if(isEmpty())
        return nullptr;
    return header -> getNext();
}

AgentNode* AgentList::getLastPos(){
    if(isEmpty())
        return nullptr;
    return header -> getPrev();
}

Agent AgentList::retrieve(AgentNode* an){
    if(!isValidPos(an))
        throw ListException("!!! POSICION INVALIDA !!!, al usar retrieve");
    return an -> getData();
}

AgentList& AgentList::operator=(const AgentList& al){
    deleteAll();
    copyAll(al);
    return *this;
}

void AgentList::swapPtr(AgentNode* x, AgentNode* y){
    if(x != y){
        Agent* aux(x -> getDataPtr());
        x -> setDataPtr(y -> getDataPtr());
        y -> setDataPtr(aux);
    }
}

void AgentList::sortByName(){
    sortByName(getFirstPos(), getLastPos());
}

void AgentList::sortByName(AgentNode* leftEdge, AgentNode* rightEdge){
    if(leftEdge == rightEdge)
        return;
    if(leftEdge -> getNext() == rightEdge){
        if(leftEdge -> getData().getAgent() > rightEdge -> getData().getAgent())
            swapPtr(leftEdge, rightEdge);
        return;
    }

    AgentNode* x(leftEdge);
    AgentNode* y(rightEdge);

    while(x != y){
        while(x != y and x -> getData().getAgent() <= rightEdge -> getData().getAgent())
            x = x -> getNext();
        while(x != y and x -> getData().getAgent() >= rightEdge -> getData().getAgent())
            y = y -> getPrev();
        swapPtr(x, y);
    }

    swapPtr(x, rightEdge);

    if(x != leftEdge)
        sortByName(leftEdge, x -> getPrev());
    if(x != rightEdge)
        sortByName(x -> getNext(), rightEdge);
}

void AgentList::sortBySpeciality(){
    sortBySpeciality(getFirstPos(), getLastPos());
}

void AgentList::sortBySpeciality(AgentNode* leftEdge, AgentNode* rightEdge){
    if(leftEdge == rightEdge)
        return;
    if(leftEdge -> getNext() == rightEdge){
        if(leftEdge -> getData().getSpeciality() > rightEdge -> getData().getSpeciality())
            swapPtr(leftEdge, rightEdge);
        return;
    }

    AgentNode* x(leftEdge);
    AgentNode* y(rightEdge);

    while(x != y){
        while(x != y and x -> getData().getSpeciality() <= rightEdge -> getData().getSpeciality())
            x = x -> getNext();
        while(x != y and x -> getData().getSpeciality() >= rightEdge -> getData().getSpeciality())
            y = y -> getPrev();
        swapPtr(x, y);
    }

    swapPtr(x, rightEdge);

    if(x != leftEdge)
        sortBySpeciality(leftEdge, x -> getPrev());
    if(x != rightEdge)
        sortBySpeciality(x -> getNext(), rightEdge);
}

void AgentList::writeToDisk(const std::string& fileName){
    ofstream file;

    file.open(fileName, file.trunc);

    if(!file.is_open()){
        string msg;

        msg = "Error al abrir el archivo ";
        msg+= fileName;
        msg+= " para escribir";

        throw ListException(msg);
    }

    AgentNode* aux(header -> getNext());

    system("rm *.calls");

    while(aux != header){
        file << aux -> getData() << endl;

        try{
            aux -> getData().getCallList().writeToDisk(aux -> getData().getIda() + ".calls");
        } catch(ListException ex){
            cout << ex.what() << endl;
          }

        aux = aux -> getNext();
    }

    file.close();
}

void AgentList::readFromDisk(const std::string& fileName){
    ifstream file;

    file.open(fileName);

    if(!file.is_open()){
        string msg;

        msg = "Error al abrir el archivo ";
        msg+= fileName;
        msg+= " para leer";

        throw ListException(msg);
    }

    Agent agnt;
    AgentNode* aux;

    deleteAll();

    while(file >> agnt){
        try{
            agnt.getCallList().readFromDisk(agnt.getIda() + ".calls");
        } catch(ListException ex){
            cout << ex.what() << endl;
          }

        if((aux = new AgentNode(agnt)) == nullptr){
            file.close();
            throw ListException("Lista vacia, readFromDisk");
        }

        aux -> setPrev(header -> getPrev());
        aux -> setNext(header);

        header -> getPrev() -> setNext(aux);
        header -> setPrev(aux);
    }

    file.close();
}
