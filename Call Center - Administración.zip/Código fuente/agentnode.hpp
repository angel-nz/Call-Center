#ifndef AGENTNODE_HPP_INCLUDED
#define AGENTNODE_HPP_INCLUDED

#include <exception>
#include <string>

#include "agent.hpp"

class AgentNodeException : public std::exception {
    private:
        std::string warn;

    public:
        explicit AgentNodeException(const char* warning) : warn(warning) { }

        explicit AgentNodeException(const std::string& warning) : warn(warning) { }

        virtual ~AgentNodeException() throw () { }

        virtual const char* what() const throw () {
            return warn.c_str();
        }
};

class AgentNode {
    private:
        Agent* dataPtr;
        AgentNode* prev;
        AgentNode* next;

    public:
        AgentNode();
        AgentNode(const Agent&);

        ~AgentNode();

        Agent* getDataPtr();
        Agent getData();
        AgentNode* getPrev();
        AgentNode* getNext();

        void setDataPtr(Agent*);
        void setData(const Agent&);
        void setPrev(AgentNode*);
        void setNext(AgentNode*);
};

#endif // AGENTNODE_HPP_INCLUDED
