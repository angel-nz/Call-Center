#include "time.hpp"

using namespace std;

int Time::toInt() const{
    return hour * 60 + minute;
}

Time::Time(){ }

Time::Time(const Time& t) : hour(t.hour), minute(t.minute) { }

int Time::getHour() const{
    return hour;
}

int Time::getMinute() const{
    return minute;
}

void Time::setHour(const int& h){
    hour = h;
}

void Time::setMinute(const int& m){
    minute = m;
}

string Time::toString() const{
    return to_string(hour) + ":" + to_string(minute);
}

Time& Time::operator=(const Time& t){
    hour = t.hour;
    minute = t.minute;

    return *this;
}

bool Time::operator==(const Time& t) const{
    return toInt() == t.toInt();
}

bool Time::operator!=(const Time& t) const{
    return toInt() != t.toInt();
}

bool Time::operator<(const Time& t) const{
    return toInt() < t.toInt();
}

bool Time::operator<=(const Time& t) const{
    return toInt() <= t.toInt();
}

bool Time::operator>(const Time& t) const{
    return toInt() > t.toInt();
}

bool Time::operator>=(const Time& t) const{
    return toInt() >= t.toInt();
}

ostream& operator << (ostream& os, const Time& t){
    os << t.toString();

    return os;
}

istream& operator >> (istream& is, Time& t){
    string term;

    getline(is, term, ':');
    t.hour = atoi(term.c_str());
    getline(is, term);
    t.minute = atoi(term.c_str());

    return is;
}
