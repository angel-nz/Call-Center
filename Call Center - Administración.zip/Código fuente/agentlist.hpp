#ifndef AGENTLIST_HPP_INCLUDED
#define AGENTLIST_HPP_INCLUDED

#include <string>
#include <fstream>

#include "agentnode.hpp"
#include "agent.hpp"

class AgentList{
    private:
        AgentNode* header;

        bool isValidPos(AgentNode*);

        void copyAll(const AgentList&);

        void swapPtr(AgentNode*, AgentNode*);

        void sortByName(AgentNode*, AgentNode*);
        void sortBySpeciality(AgentNode*, AgentNode*);

    public:
        AgentList();
        AgentList(const AgentList&);

        ~AgentList();

        bool isEmpty();

        void insertData(AgentNode*, const Agent&);

        void deleteData(AgentNode*);

        AgentNode* getFirstPos();
        AgentNode* getLastPos();
        AgentNode* getPrevPos(AgentNode*);
        AgentNode* getNextPos(AgentNode*);

        AgentNode* findData(const Agent&);

        Agent retrieve(AgentNode*);

        void sortByName();
        void sortBySpeciality();

        std::string toString(const bool&);

        void deleteAll();

        void writeToDisk(const std::string&);
        void readFromDisk(const std::string&);

        AgentList& operator = (const AgentList&);
};

#endif // AGENTLIST_HPP_INCLUDED
