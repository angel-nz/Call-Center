#ifndef TIME_HPP_INCLUDED
#define TIME_HPP_INCLUDED

#include <iostream>
#include <string>

class Time{
    private:
        int hour;
        int minute;

        int toInt() const;

    public:
        Time();
        Time(const Time &);

        int getHour() const;
        int getMinute() const;

        void setHour(const int&);
        void setMinute(const int&);

        std::string toString() const;

        Time& operator = (const Time&);

        bool operator == (const Time&) const;
        bool operator != (const Time&) const;
        bool operator < (const Time&) const;
        bool operator <= (const Time&) const;
        bool operator > (const Time&) const;
        bool operator >= (const Time&) const;

        friend std::ostream& operator << (std::ostream&, Time&);
        friend std::istream& operator >> (std::istream&, Time&);
};

#endif // TIME_HPP_INCLUDED
