#include "callmenu.hpp"

using namespace std;

void CallMenu::enterToContinue(){
    setlocale(LC_CTYPE, "spanish");

    cout << "�Presione ENTER para continuar!";
    getchar();
}

CallMenu::CallMenu(CallList* cl) : callListRef(cl){
    mainMenu();
}

void CallMenu::mainMenu(){
    setlocale(LC_CTYPE, "spanish");

    int op;

    do{
        system("cls");

        cout << "Call Center - Administraci�n" << endl << endl;
        cout << "Men� de Clientes [Llamadas]" << endl << endl;
        cout << "0. Salir" << endl;
        cout << "1. A�adir llamada" << endl;
        cout << "2. Modificar llamada" << endl;
        cout << "3. Eliminar llamada" << endl;
        cout << "4. Eliminar lista" << endl;
        cout << "5. Mostrar lista" << endl << endl;
        cout << "Ingrese el no. de Acci�n: "; cin >> op; cin.ignore();

        switch(op){
            case 0:
                cout << endl << "||| SALIDA de la lista de llamadas EXITOSA |||" << endl << endl;
                enterToContinue(); break;
            case 1: addCall(); break;
            case 2: modifyCall(); break;
            case 3: deleteCall(); break;
            case 4: deleteAll(); break;
            case 5: showCallList(); break;
            default:
                cout << "!!! ACCI�N INV�LIDA !!!" << endl << endl;
                enterToContinue();
        }
    } while(op != 0);
}

void CallMenu::addCall(){
    setlocale(LC_CTYPE, "spanish");

    string cTerm;
    CallNode* pos;
    Call cCall;
    Name cName;
    Time cTime;

    system("cls");

    cout << "Nueva llamada" << endl << endl;
    cout << "Id-C: "; cin >> cTerm;
    cCall.setIdc(cTerm);

    pos = callListRef -> findData(cCall);

    if(pos != nullptr){
        cout << "!!! ID-C REPETIDO !!!";
        enterToContinue();

        return;
    }

    cout << "Nombre(s) del Cliente: ";
    cin.get();
    getline(cin, cTerm);
    cName.setFirst(cTerm);
    cout << "Apellido(s) del Cliente: ";
    getline(cin, cTerm);
    cName.setLast(cTerm);
    cCall.setClient(cName);

    cout << "Hora (HH:MM): ";
    getline(cin, cTerm, ':');
    cTime.setHour(stoi(cTerm));
    getline(cin, cTerm);
    cTime.setMinute(stoi(cTerm));
    cCall.setAttention(cTime);

    cout << "Duraci�n (HH:MM): ";
    getline(cin, cTerm, ':');
    cTime.setHour(stoi(cTerm));
    getline(cin, cTerm);
    cTime.setMinute(stoi(cTerm));
    cCall.setDuration(cTime);

    try{
        callListRef -> insertOrdered(cCall);
    } catch (ListException& warn){
        cout << "!!! ERROR !!!" << endl;
        cout << "Reporte: " << warn.what() << endl;
        cout << "Si el error persiste comuniquese con Servicio al cliente" << endl << endl;
        enterToContinue();

        return;
    }

    cout << endl << "Llamada a�adida con �xito" << endl << endl;
    enterToContinue();
}

void CallMenu::deleteCall(){
    setlocale(LC_CTYPE, "spanish");

    string cTerm;
    char op;
    Call cCall;
    Name cName;
    CallNode* pos;

    system("cls");

    cout << "LISTA DE LLAMADAS" << endl << endl;
    cout << callListRef -> toString();
    cout << endl;

    cout << "~ Eliminar llamada" << endl << endl;
    cout << "Id-C: "; cin >> cTerm;
    cCall.setIdc(cTerm);

    pos = callListRef -> findData(cCall);

    if(pos != nullptr){
        do{
            cout << endl << "Confirmar eliminaci�n (s/n): "; cin >> op; cin.ignore();
            op = toupper(op);
        } while(op != 'N' and op != 'S');

        if(op == 'S'){
            callListRef -> deleteData(pos);
            cout << endl << "Llamada eliminada con �xito" << endl << endl;
            enterToContinue();
        }
    }
    else{
        cout << "!!! LLAMADA INEXISTENTE !!!" << endl << endl;
        enterToContinue();
    }
}

void CallMenu::deleteAll(){
    setlocale(LC_CTYPE, "spanish");

    char op;

    system("cls");

    cout << "Eliminar lista" << endl << endl;
    do{
        cout << "Confirmar (s/n): "; cin >> op; cin.ignore();
        op = toupper(op);
    } while(op != 'N' and op != 'S');

    if(op == 'S'){
        callListRef -> deleteAll();

        cout << endl << "Lista eliminada con �xito" << endl << endl;
        enterToContinue();
    }
}

void CallMenu::modifyCall(){
    setlocale(LC_CTYPE, "spanish");

    string cTerm;
    Call cCall;
    Name cName;
    Time cTime;
    CallNode* pos;

    system("cls");

    cout << "LISTA DE LLAMADAS" << endl << endl;
    cout << callListRef -> toString();
    cout << endl;

    cout << "* Modificar duraci�n de llamada" << endl << endl;
    cout << "Id-C: "; cin >> cTerm;
    cCall.setIdc(cTerm);

    pos = callListRef -> findData(cCall);

    cout << endl << "CONFIRMAR INFO" << endl << endl;
    cout << "Nombre(s) del Cliente: ";
    cin.get();
    getline(cin, cTerm);
    cName.setFirst(cTerm);
    cout << "Apellido(s) del Cliente: ";
    getline(cin, cTerm);
    cName.setLast(cTerm);
    cCall.setClient(cName);

    cout << "Hora (HH:MM): ";
    getline(cin, cTerm, ':');
    cTime.setHour(stoi(cTerm));
    getline(cin, cTerm);
    cTime.setMinute(stoi(cTerm));
    cCall.setAttention(cTime);

    if(pos != nullptr){
        cout << "Nueva duraci�n (HH:MM): ";
        getline(cin, cTerm, ':');
        cTime.setHour(stoi(cTerm));
        getline(cin, cTerm);
        cTime.setMinute(stoi(cTerm));
        cCall.setDuration(cTime);
        try{
            callListRef -> deleteData(pos);
            callListRef -> insertOrdered(cCall);
        } catch (ListException& warn){
            cout << "!!! ERROR !!!" << endl;
            cout << "Reporte: " << warn.what() << endl;
            cout << "Si el error persiste comuniquese con Servicio al cliente" << endl << endl;
            enterToContinue();
            return;
        }

        cout << endl << "Llamada modificada con �xito" << endl << endl;
        enterToContinue();
    }
    else{
        cout << "!!! LLAMADA INEXISTENTE !!!" << endl << endl;
        enterToContinue();
    }
}

void CallMenu::showCallList(){
    system("cls");

    cout << "LISTA DE LLAMADAS" << endl << endl;
    cout << callListRef -> toString();
    cout << endl;
    enterToContinue();
}
