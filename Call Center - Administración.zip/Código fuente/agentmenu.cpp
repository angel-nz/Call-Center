#include "agentmenu.hpp"

using namespace std;

void AgentMenu::enterToContinue(){
    setlocale(LC_CTYPE, "spanish");

    cout << "�Presione ENTER para continuar!";
    getchar();
}

AgentMenu::AgentMenu(AgentList* al) : agentListRef(al) {
    mainMenu();
}

void AgentMenu::mainMenu(){
    setlocale(LC_CTYPE, "spanish");

    int op;
    system("cls");
    cout << "\n\n\
       CCCCCCCCCCCCC      AAAAAAAAAAAAA   LLLLLLL            LLLLLLL\n\
     CC:::::::::::::CC  AA:::::::::::::AA L:::::L            L:::::L\n\
    C::::::CCCCC::::::CA:::::::::::::::::AL:::::L            L:::::L\n\
    C:::::C     CCCCCCCA::::::AAAAA::::::AL:::::L            L:::::L\n\
    C:::::C            A:::::A     A:::::AL:::::L            L:::::L\n\
    C:::::C            A:::::A     A:::::AL:::::L            L:::::L\n\
    C:::::C            A:::::AAAAAAA:::::AL:::::L            L:::::L\n\
    C:::::C            A:::::::::::::::::AL:::::L            L:::::L\n\
    C:::::C            A:::::::::::::::::AL:::::L            L:::::L\n\
    C:::::C            A:::::AAAAAAA:::::AL:::::L            L:::::L\n\
    C:::::C            A:::::A     A:::::AL:::::L            L:::::L\n\
    C:::::C            A:::::A     A:::::AL:::::L            L:::::L\n\
    C:::::C     CCCCCCCA:::::A     A:::::AL:::::LLLLLLLLLLLLLL:::::LLLLLLLLLLLLL\n\
    C::::::CCCCC::::::CA:::::A     A:::::AL:::::::::::::::::LL:::::::::::::::::L\n\
     CC:::::::::::::CC A:::::A     A:::::AL:::::::::::::::::LL:::::::::::::::::L\n\
       CCCCCCCCCCCCC   AAAAAAA     AAAAAAALLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLL\n\
    \n\
       CCCCCCCCCCCCC   EEEEEEEEEEEEEEEEEEENNNNNN      NNNNNNNTTTTTTTTTTTTTTTTTTTEEEEEEEEEEEEEEEEEEERRRRRRRRRRRRRRRR\n\
     CC:::::::::::::CC E:::::::::::::::::EN::::N      N:::::NT:::::::::::::::::TE:::::::::::::::::ER:::::::::::::::RR\n\
    C::::::CCCCC::::::CE:::::::::::::::::EN:::::N     N:::::NT:::::::::::::::::TE:::::::::::::::::ER:::::::::::::::::R\n\
    C:::::C     CCCCCCCE:::::EEEEEEEEEEEEEN::::::N    N:::::NTTTTTTT:::::TTTTTTTE:::::EEEEEEEEEEEEER:::::RRRRRR::::::R\n\
    C:::::C            E:::::E            N:::::::N   N:::::N      T:::::T      E:::::E            R:::::R     R:::::R\n\
    C:::::C            E:::::E            N::::::::N  N:::::N      T:::::T      E:::::E            R:::::R     R:::::R\n\
    C:::::C            E:::::EEEEEEEEEEE  N:::::::::N N:::::N      T:::::T      E:::::EEEEEEEEEEE  R:::::RRRRRR::::::R\n\
    C:::::C            E:::::::::::::::E  N::::::::::NN:::::N      T:::::T      E:::::::::::::::E  R::::::::::::::::R\n\
    C:::::C            E:::::EEEEEEEEEEE  N:::::NN::::::::::N      T:::::T      E:::::EEEEEEEEEEE  R:::::::::::::RRR\n\
    C:::::C            E:::::E            N:::::N N:::::::::N      T:::::T      E:::::E            R:::::RR:::::R\n\
    C:::::C            E:::::E            N:::::N  N::::::::N      T:::::T      E:::::E            R:::::R R:::::R\n\
    C:::::C            E:::::E            N:::::N   N:::::::N      T:::::T      E:::::E            R:::::R  R:::::R\n\
    C:::::C     CCCCCCCE:::::EEEEEEEEEEEEEN:::::N    N::::::N      T:::::T      E:::::EEEEEEEEEEEEER:::::R   R:::::R\n\
    C::::::CCCCC::::::CE:::::::::::::::::EN:::::N     N:::::N      T:::::T      E:::::::::::::::::ER:::::R    R:::::R\n\
     CC:::::::::::::CC E:::::::::::::::::EN:::::N      N::::N      T:::::T      E:::::::::::::::::ER:::::R     R:::::R\n\
       CCCCCCCCCCCCC   EEEEEEEEEEEEEEEEEEENNNNNNN      NNNNNN      TTTTTTT      EEEEEEEEEEEEEEEEEEERRRRRRR      RRRRRRR\n\
    \n\
    " << endl;

    cout << "    CALL CENTER - [ADMINISTRACI�N]" << endl << endl << "    ";

    enterToContinue();

    do{
        system("cls");

        cout << "Men� de Agentes" << endl << endl;
        cout << "0. Salir" << endl;
        cout << "1. A�adir agente" << endl;
        cout << "2. Buscar agente" << endl;
        cout << "3. Modificar agente" << endl;
        cout << "4. Eliminar agente" << endl;
        cout << "5. Mostrar lista" << endl;
        cout << "6. Eliminar lista" << endl;
        cout << "7. Escribir al disco" << endl;
        cout << "8. Leer del disco" << endl << endl;
        cout << "Ingrese el no. de Acci�n: "; cin >> op; cin.ignore();

        switch(op){
            case 0:
                system("cls");
                cout << endl << "||| SALIDA EXITOSA |||" << endl << endl;
                enterToContinue();
                system("cls");

                cout << "\n\n\
                   CCCCCCCCCCCCC      AAAAAAAAAAAAA   LLLLLLL            LLLLLLL\n\
                 CC:::::::::::::CC  AA:::::::::::::AA L:::::L            L:::::L\n\
                C::::::CCCCC::::::CA:::::::::::::::::AL:::::L            L:::::L\n\
                C:::::C     CCCCCCCA::::::AAAAA::::::AL:::::L            L:::::L\n\
                C:::::C            A:::::A     A:::::AL:::::L            L:::::L\n\
                C:::::C            A:::::A     A:::::AL:::::L            L:::::L\n\
                C:::::C            A:::::AAAAAAA:::::AL:::::L            L:::::L\n\
                C:::::C            A:::::::::::::::::AL:::::L            L:::::L\n\
                C:::::C            A:::::::::::::::::AL:::::L            L:::::L\n\
                C:::::C            A:::::AAAAAAA:::::AL:::::L            L:::::L\n\
                C:::::C            A:::::A     A:::::AL:::::L            L:::::L\n\
                C:::::C            A:::::A     A:::::AL:::::L            L:::::L\n\
                C:::::C     CCCCCCCA:::::A     A:::::AL:::::LLLLLLLLLLLLLL:::::LLLLLLLLLLLLL\n\
                C::::::CCCCC::::::CA:::::A     A:::::AL:::::::::::::::::LL:::::::::::::::::L\n\
                 CC:::::::::::::CC A:::::A     A:::::AL:::::::::::::::::LL:::::::::::::::::L\n\
                   CCCCCCCCCCCCC   AAAAAAA     AAAAAAALLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLL\n\
                \n\
                   CCCCCCCCCCCCC   EEEEEEEEEEEEEEEEEEENNNNNN      NNNNNNNTTTTTTTTTTTTTTTTTTTEEEEEEEEEEEEEEEEEEERRRRRRRRRRRRRRRR\n\
                 CC:::::::::::::CC E:::::::::::::::::EN::::N      N:::::NT:::::::::::::::::TE:::::::::::::::::ER:::::::::::::::RR\n\
                C::::::CCCCC::::::CE:::::::::::::::::EN:::::N     N:::::NT:::::::::::::::::TE:::::::::::::::::ER:::::::::::::::::R\n\
                C:::::C     CCCCCCCE:::::EEEEEEEEEEEEEN::::::N    N:::::NTTTTTTT:::::TTTTTTTE:::::EEEEEEEEEEEEER:::::RRRRRR::::::R\n\
                C:::::C            E:::::E            N:::::::N   N:::::N      T:::::T      E:::::E            R:::::R     R:::::R\n\
                C:::::C            E:::::E            N::::::::N  N:::::N      T:::::T      E:::::E            R:::::R     R:::::R\n\
                C:::::C            E:::::EEEEEEEEEEE  N:::::::::N N:::::N      T:::::T      E:::::EEEEEEEEEEE  R:::::RRRRRR::::::R\n\
                C:::::C            E:::::::::::::::E  N::::::::::NN:::::N      T:::::T      E:::::::::::::::E  R::::::::::::::::R\n\
                C:::::C            E:::::EEEEEEEEEEE  N:::::NN::::::::::N      T:::::T      E:::::EEEEEEEEEEE  R:::::::::::::RRR\n\
                C:::::C            E:::::E            N:::::N N:::::::::N      T:::::T      E:::::E            R:::::RR:::::R\n\
                C:::::C            E:::::E            N:::::N  N::::::::N      T:::::T      E:::::E            R:::::R R:::::R\n\
                C:::::C            E:::::E            N:::::N   N:::::::N      T:::::T      E:::::E            R:::::R  R:::::R\n\
                C:::::C     CCCCCCCE:::::EEEEEEEEEEEEEN:::::N    N::::::N      T:::::T      E:::::EEEEEEEEEEEEER:::::R   R:::::R\n\
                C::::::CCCCC::::::CE:::::::::::::::::EN:::::N     N:::::N      T:::::T      E:::::::::::::::::ER:::::R    R:::::R\n\
                 CC:::::::::::::CC E:::::::::::::::::EN:::::N      N::::N      T:::::T      E:::::::::::::::::ER:::::R     R:::::R\n\
                   CCCCCCCCCCCCC   EEEEEEEEEEEEEEEEEEENNNNNNN      NNNNNN      TTTTTTT      EEEEEEEEEEEEEEEEEEERRRRRRR      RRRRRRR\n\
                \n\
                " << endl;

                cout << "                CALL CENTER - [ADMINISTRACI�N]" << endl << endl << "    ";

            break;
            case 1: addAgent(); break;
            case 2: findAgent(); break;
            case 3: modifyAgent(); break;
            case 4: deleteAgent(); break;
            case 5: showAgentList(); break;
            case 6: deleteAll(); break;
            case 7: writeToDisk(); break;
            case 8: readFromDisk(); break;
            default:
                cout << "!!! ACCI�N INV�LIDA !!!" << endl << endl;
                enterToContinue();
        }
    }while(op != 0);
}

void AgentMenu::addAgent(){
    setlocale(LC_CTYPE, "spanish");

    Agent aAgent;
    Time aTime;
    Name aName;
    AgentNode* pos;
    string aTerm;
    char op;

    system("cls");

    cout << "\tNuevo agente" << endl << endl;
    cout << "Nombre(s) del Agente: ";
    getline(cin, aTerm);
    aName.setFirst(aTerm);
    cout << "Apellido(s) del Agente: ";
    getline(cin, aTerm);
    aName.setLast(aTerm);
    aAgent.setAgent(aName);

    pos = agentListRef -> findData(aAgent);

    if(pos != nullptr){
        cout << "!!! AGENTE REPETIDO !!!";
        enterToContinue();

        return;
    }

    cout << "ID-A: "; cin >> aTerm;
    aAgent.setIda(aTerm);

    cout << "Especialidad: ";
    cin.get();
    getline(cin, aTerm);
    aAgent.setSpeciality(aTerm);

    cout << "Extensi�n (####): ";
    getline(cin, aTerm);
    aAgent.setExtension(aTerm);

    cout << "Horario (HH:MM): ";
    getline(cin, aTerm, ':');
    aTime.setHour(stoi(aTerm));
    getline(cin, aTerm);
    aTime.setMinute(stoi(aTerm));
    aAgent.setSchedule(aTime);

    cout << "Horas Extras (HH:MM): ";
    getline(cin, aTerm, ':');
    aTime.setHour(stoi(aTerm));
    getline(cin, aTerm);
    aTime.setMinute(stoi(aTerm));
    aAgent.setXhour(aTime);

    do{
        cout << endl << "�Desea ir a la Lista de Llamadas para agregar clientes al agente? (s/n): "; cin >> op; cin.ignore();
        op = toupper(op);
    }while(op != 'S' && op != 'N');

    if(op == 'S')
        new CallMenu(&aAgent.getCallList());
    try{
        agentListRef -> insertData(agentListRef -> getLastPos(), aAgent);
    } catch (ListException& warn){
        cout << "!!! ERROR !!!" << endl;
        cout << "Reporte: " << warn.what() << endl;
        cout << "Si el error persiste comuniquese con Control de Agentes" << endl << endl;
        enterToContinue();

        return;
    }
    system("cls");
    cout << endl << "Agente a�adido con �xito" << endl << endl;
    enterToContinue();
}

void AgentMenu::findAgent(){
    setlocale(LC_CTYPE, "spanish");

    string aTerm;
    char op;
    Agent aAgent;
    Name aName;
    AgentNode* pos;
    CallList* callListRef;

    system("cls");

    cout << "LISTA DE AGENTES" << endl << endl;
    cout << agentListRef -> toString(false);
    cout << endl;

    cout << "Buscar agente" << endl << endl;
    cout << "Nombre(s) del Agente: ";
    getline(cin, aTerm);
    aName.setFirst(aTerm);
    cout << "Apellido(s) del Agente: ";
    getline(cin, aTerm);
    aName.setLast(aTerm);
    aAgent.setAgent(aName);

    pos = agentListRef -> findData(aAgent);

    if(pos != nullptr){
        do{
            cout << endl << "Agente encontrado:" << endl;
            cout << "ID-A | Nombre del Agente | Especialidad | Extensi�n | Horario | Horas Extra" << endl;
            cout << pos -> getData().toString(false) << endl << endl;
            cout << "�Mostrar los respectivos clientes? (s/n): "; cin >> op; cin.ignore();

            op = toupper(op);
        }while(op != 'S' && op != 'N');

        if(op == 'S'){
            system("cls");

            cout << "Agente encontrado:" << endl;
            cout << pos -> getData().toString(true);
        }
        else{
            system("cls");

            cout << "Agente encontrado:" << endl;
            cout << pos -> getData().toString(false);
        }
        do{
            cout << endl << "�Desea ir a la Lista de Llamadas para configurar clientes del agente? (s/n): "; cin >> op; cin.ignore();
            op = toupper(op);
        }while(op != 'S' && op != 'N');

        if(op == 'S')

            CallMenu(&aAgent.getCallList()); /// <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
    }
    else{
        cout << "!!! AGENTE INEXISTENTE !!!" << endl << endl;
        enterToContinue();
    }
}

void AgentMenu::modifyAgent(){
    setlocale(LC_CTYPE, "spanish");

    string aTerm;
    Agent aAgent;
    Name aName;
    Time aTime;
    AgentNode* pos;

    system("cls");

    cout << "LISTA DE AGENTES" << endl << endl;
    cout << agentListRef -> toString(false);
    cout << endl;

    cout << "Modificar informaci�n del Agente" << endl << endl;
    cout << "Nombre(s) del Agente: ";
    getline(cin, aTerm);
    aName.setFirst(aTerm);
    cout << "Apellido(s) del Agente: ";
    getline(cin, aTerm);
    aName.setLast(aTerm);
    aAgent.setAgent(aName);

    pos = agentListRef -> findData(aAgent);

    if(pos != nullptr){
        cout << endl << "CONFIRMAR INFO" << endl << endl;
        cout << "ID-A: "; cin >> aTerm;
        aAgent.setIda(aTerm);

        cout << "Especialidad: ";
        cin.get();
        getline(cin, aTerm);
        aAgent.setSpeciality(aTerm);

        cout << "Extensi�n (####): ";
        getline(cin, aTerm);
        aAgent.setExtension(aTerm);

        cout << "Horario (HH:MM): ";
        getline(cin, aTerm, ':');
        aTime.setHour(stoi(aTerm));
        getline(cin, aTerm);
        aTime.setMinute(stoi(aTerm));
        aAgent.setSchedule(aTime);

        cout << "Horas Extras (HH:MM): ";
        getline(cin, aTerm, ':');
        aTime.setHour(stoi(aTerm));
        getline(cin, aTerm);
        aTime.setMinute(stoi(aTerm));
        aAgent.setXhour(aTime);

        try{
            agentListRef -> deleteData(pos);
            agentListRef -> insertData(agentListRef -> getLastPos(), aAgent);
        } catch (ListException& warn){
            cout << "!!! ERROR !!!" << endl;
            cout << "Reporte: " << warn.what() << endl;
            cout << "Si el error persiste comuniquese con Control de Agentes" << endl << endl;
            enterToContinue();
            return;
        }
        cout << endl << "Agente modificado con �xito" << endl << endl;
        enterToContinue();
    }
    else{
        cout << "!!! AGENTE INEXISTENTE !!!" << endl << endl;
        enterToContinue();
    }
}

void AgentMenu::showAgentList(){
    setlocale(LC_CTYPE, "spanish");

    char op;

    system("cls");

    cout << "LISTA DE AGENTES" << endl << endl;

    sortAgent();

    do{
        cout << "�Mostrar los respectivos clientes? (s/n): "; cin >> op; cin.ignore();
        op = toupper(op);
    }while(op != 'S' && op != 'N');

    cout << endl << endl;

    if(op == 'S')
        cout << agentListRef->toString(true);
    else{
        cout << "Agentes:\nID-A | Nombre del Agente | Especialidad | Extensi�n | Horario | Horas Extra\n";
        cout << agentListRef->toString(false);
    }

    cout << endl << endl;

    enterToContinue();
}

void AgentMenu::deleteAgent(){
    setlocale(LC_CTYPE, "spanish");

    string aTerm;
    char op;
    Agent aAgent;
    Name aName;
    AgentNode* pos;

    system("cls");

    cout << "LISTA DE AGENTES" << endl << endl;
    cout << agentListRef -> toString(false);
    cout << endl;

    cout << "~ Eliminar agente" << endl << endl;
    cout << "Nombre(s) del Agente: ";
    getline(cin, aTerm);
    aName.setFirst(aTerm);
    cout << "Apellido(s) del Agente: ";
    getline(cin, aTerm);
    aName.setLast(aTerm);
    aAgent.setAgent(aName);

    pos = agentListRef -> findData(aAgent);

    if(pos != nullptr){
        do{
            cout << endl << "Confirmar eliminaci�n (s/n): "; cin >> op; cin.ignore();
            op = toupper(op);
        } while(op != 'N' and op != 'S');

        if(op == 'S'){
            agentListRef -> deleteData(pos);
            cout << endl << "Agente eliminado con �xito" << endl << endl;
            enterToContinue();
        }
    }
    else{
        cout << "!!! AGENTE INEXISTENTE !!!" << endl << endl;
        enterToContinue();
    }
}

void AgentMenu::deleteAll(){
    setlocale(LC_CTYPE, "spanish");

    char op;

    system("cls");

    cout << "Eliminar listas" << endl << endl;
    do{
        cout << "Confirmar (s/n): "; cin >> op; cin.ignore();
        op = toupper(op);
    } while(op != 'N' and op != 'S');

    if(op == 'S'){
        agentListRef -> deleteAll();

        cout << endl << "Listas eliminadas con �xito" << endl << endl;
        enterToContinue();
    }
}

void AgentMenu::sortAgent(){
    setlocale(LC_CTYPE, "spanish");

    int op;

    cout << "ORDENAR" << endl;
    cout << "1. Por Nombre\n2. Por Especialidad" << endl;
    do{
        cout << "Ingrese el no. de Acci�n: "; cin >> op; cin.ignore();
        op = toupper(op);
    }while(op != 1 && op != 2);

    cout << endl;

    if(op == 1)
        agentListRef -> sortByName();
    else
        agentListRef -> sortBySpeciality();
}

void AgentMenu::writeToDisk(){
    system("cls");

    cout << "Escribiendo al disco..." << endl << endl;

    try{
        agentListRef -> writeToDisk("agents.list");
    } catch(ListException ex){
        cout << "Hubo un problema..." << endl;
        cout << ex.what() << endl;

        enterToContinue();

        return;
      }

    cout << "Escritura exitosa" << endl << endl;

    enterToContinue();
}

void AgentMenu::readFromDisk(){
    system("cls");

    cout << "Leyendo archivo...";

    try{
        agentListRef -> readFromDisk("agents.list");
    } catch (ListException ex){
      cout << "Hubo un problema..." << endl;
      cout << ex.what() << endl << endl;

      enterToContinue();

      return;
      }

      cout << "La lectura finalizo exitosamente" << endl << endl;

      enterToContinue();
}
