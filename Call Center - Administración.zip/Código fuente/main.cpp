#include "agentmenu.hpp"

using namespace std;

int main(){
    new AgentMenu(new AgentList);
}
