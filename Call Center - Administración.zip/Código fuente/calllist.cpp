#include "calllist.hpp"

using namespace std;

bool CallList::isValidPos(CallNode* cn){
    CallNode* aux(anchor);

    while(aux != nullptr){
        if(aux == cn)
            return true;
        aux = aux -> getNext();
    }

    return false;
}

CallList::CallList() : anchor(nullptr) { }

bool CallList::isEmpty(){
    return anchor == nullptr;
}

string CallList::toString() const{
    CallNode* aux(anchor);
    string info;

    while(aux != nullptr){
        info+= aux -> getData().toString() + "\n";
        aux = aux -> getNext();
    }

    return info;
}

void CallList::insertData(CallNode* cn, const Call& c){
    if(cn != nullptr and !isValidPos(cn))
        throw ListException("!!! POSICION INVALIDA !!!, al usar insertData");

    CallNode* aux(new CallNode(c));

    if(aux == nullptr)
        throw ListException("!!! LISTA LLENA !!!, al usar insertData");

    if(cn == nullptr){
        aux -> setNext(anchor);
        anchor = aux;
    }
    else{
        aux -> setNext(cn -> getNext());
        cn -> setNext(aux);
    }
}

void CallList::insertOrdered(const Call& c){
    CallNode* aux(anchor);
    CallNode* cn(nullptr);

    while(aux != nullptr and c > aux -> getData()){
        cn = aux;
        aux = aux -> getNext();
    }

    insertData(cn, c);
}

CallNode* CallList::getPrevPos(CallNode* cn){
    if(cn == anchor or !isValidPos(cn))
        return nullptr;

    CallNode* aux(anchor);

    while(aux -> getNext() != cn)
        aux = aux -> getNext();

    return aux;
}

void CallList::deleteData(CallNode* cn){
    if(!isValidPos(cn))
        throw ListException("!!! POSICION INVALIDA !!!, al usar deleteData");
    if(cn == anchor)
        anchor = cn -> getNext();
    else
        getPrevPos(cn) -> setNext(cn -> getNext());

    delete cn;
}

CallNode* CallList::findData(const Call& c){
    CallNode* aux(anchor);

    while(aux != nullptr and aux -> getData() != c)
        aux = aux -> getNext();

    return aux;
}

void CallList::deleteAll(){
    CallNode* aux;

    while(anchor != nullptr){
        aux = anchor;
        anchor = anchor -> getNext();
        delete aux;
    }
}

CallList::~CallList(){
    deleteAll();
}

void CallList::copyAll(const CallList& cl){
    CallNode* aux(cl.anchor);
    CallNode* last(nullptr);
    CallNode* newNode;

    while(aux != nullptr){
        newNode = new CallNode(aux -> getData());
        if(newNode == nullptr)
            throw ListException("!!! LISTA LLENA, al usar copyAll");
        if(last == nullptr)
            anchor = newNode;
        else
            last -> setNext(newNode);
        last = newNode;
        aux = aux -> getNext();
    }
}

CallList::CallList(const CallList& cl) : CallList(){
    copyAll(cl);
}

CallNode* CallList::getFirstPos(){
    return anchor;
}

CallNode* CallList::getLastPos(){
    if(isEmpty())
        return nullptr;

    CallNode* aux(anchor);

    while(aux -> getNext() != nullptr)
        aux = aux -> getNext();

    return aux;
}

CallNode* CallList::getNextPos(CallNode* cn){
    if(!isValidPos(cn))
        return nullptr;

    return cn -> getNext();
}

Call CallList::retrieve(CallNode* cn){
    if(!isValidPos(cn))
        throw ListException("!!! POSICION INVALIDA !!!, al usar retrieve");

    return cn -> getData();
}

CallList& CallList::operator=(const CallList& cl){
    deleteAll();
    copyAll(cl);

    return *this;
}

void CallList::writeToDisk(const string& fileName){
    ofstream file;

    file.open(fileName, file.trunc);

    if(!file.is_open()){
        string msg;

        msg = "Error al abrir el archivo ";
        msg+= fileName;
        msg+= " para escribir";

        throw ListException(msg);
    }

    CallNode* aux(anchor);

    while(aux != nullptr){
        file << aux -> getData() << endl;
        aux = aux -> getNext();
    }

    file.close();
}

void CallList::readFromDisk(const string& fileName){
    ifstream file;

    file.open(fileName);

    if(!file.is_open()){
        string msg;

        msg = "Error al abrir el archivo ";
        msg+= fileName;
        msg+= " para leer";

        throw ListException(msg);
    }

    deleteAll();

    Call cl;
    CallNode* last(nullptr);
    CallNode* newNode;

    while(file >> cl){
        if((newNode = new CallNode(cl)) == nullptr){
            file.close();
            throw ListException("Lista vacia, readFromDisk");
        }
        if(last == nullptr)
            anchor = newNode;
        else
            last -> setNext(newNode);

        last = newNode;
    }

    file.close();
}
