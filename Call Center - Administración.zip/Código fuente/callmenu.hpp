#ifndef CALLMENU_HPP_INCLUDED
#define CALLMENU_HPP_INCLUDED

#include <iostream>
#include <string>
#include <locale>

#include "calllist.hpp"
#include "callnode.hpp"
#include "call.hpp"
#include "time.hpp"

class CallMenu {
    private:
        CallList* callListRef;

        void enterToContinue();

        void mainMenu();
        void addCall();
        void deleteCall();
        void deleteAll();
        void modifyCall();
        void showCallList();

    public:
        CallMenu(CallList*);
};

#endif // CALLMENU_HPP_INCLUDED
