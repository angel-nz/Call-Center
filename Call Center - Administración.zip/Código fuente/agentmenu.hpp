#ifndef AGENTMENU_HPP_INCLUDED
#define AGENTMENU_HPP_INCLUDED

#include <iostream>
#include <cstdlib>
#include <clocale>
#include <string>

#include "agentlist.hpp"
#include "agent.hpp"
#include "name.hpp"
#include "time.hpp"
#include "calllist.hpp"
#include "callmenu.hpp"

class AgentMenu {
    private:
        AgentList* agentListRef;

        void enterToContinue();

        void mainMenu();

        void addAgent();
        void findAgent();
        void modifyAgent();
        void deleteAgent();
        void showAgentList();
        void deleteAll();

        void sortAgent();

        void writeToDisk();
        void readFromDisk();

    public:
        AgentMenu(AgentList*);
};

#endif // AGENTMENU_HPP_INCLUDED
