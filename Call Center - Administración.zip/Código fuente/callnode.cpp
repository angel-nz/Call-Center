#include "callnode.hpp"

using namespace std;

CallNode::CallNode() : next(nullptr) { }

CallNode::CallNode(const Call& cn) : data(cn), next(nullptr) { }

Call CallNode::getData() const{
    return data;
}

CallNode* CallNode::getNext(){
    return next;
}

void CallNode::setData(const Call& d){
    data = d;
}

void CallNode::setNext(CallNode* n){
    next = n;
}
