#ifndef CALL_HPP_INCLUDED
#define CALL_HPP_INCLUDED

#include <iostream>
#include <string>

#include "time.hpp"
#include "name.hpp"

class Call {
    private:
        std::string idc;
        Name client;
        Time attention;
        Time duration;

    public:
        Call();
        Call(const Call&);

        std::string getIdc() const;
        Name getClient() const;
        Time getAttention() const;
        Time getDuration() const;

        void setIdc(const std::string& );
        void setClient(const Name& );
        void setAttention(const Time& );
        void setDuration(const Time& );

        std::string toString() const;

        Call& operator = (const Call&);

        bool operator == (const Call&) const;
        bool operator != (const Call&) const;
        bool operator < (const Call&) const;
        bool operator <= (const Call&) const;
        bool operator > (const Call&) const;
        bool operator >= (const Call&) const;

        friend std::ostream& operator << (std::ostream&, const Call&);
        friend std::istream& operator >> (std::istream&, Call&);
};

#endif // CALL_HPP_INCLUDED
