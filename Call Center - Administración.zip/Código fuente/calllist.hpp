#ifndef CALLLIST_HPP_INCLUDED
#define CALLLIST_HPP_INCLUDED

#include <string>
#include <fstream>

#include "listexception.hpp"
#include "callnode.hpp"

class CallList{
    private:
        CallNode* anchor;

        bool isValidPos(CallNode*);

        void copyAll(const CallList&);

    public:
        CallList();
        CallList(const CallList&);

        ~CallList();

        bool isEmpty();

        void insertData(CallNode*, const Call&);

        void insertOrdered(const Call&);

        void deleteData(CallNode*);

        CallNode* getFirstPos();
        CallNode* getLastPos();
        CallNode* getPrevPos(CallNode*);
        CallNode* getNextPos(CallNode*);

        CallNode* findData(const Call&);

        Call retrieve(CallNode*);

        std::string toString() const;

        void deleteAll();

        void writeToDisk(const std::string&);
        void readFromDisk(const std::string&);

        CallList& operator = (const CallList&);
};

#endif // CALLLIST_HPP_INCLUDED
